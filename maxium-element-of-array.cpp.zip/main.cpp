#include<iostream>
using namespace std;
int main(){
    int arr[]={3,5,8,9,7,6};
    int n=sizeof(arr)/4;
    int mx=arr[0];
    for(int i=1;i<n;i++){
    if(arr[i]>mx) mx=arr[i];
    }
    cout<<mx;
    return 0;
}